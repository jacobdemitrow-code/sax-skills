---
name: "sax-core"
description: "Jacob's SAX (StratAI Apex) rulebook: house rules, the ask-first list, the 10 services and prices, brand, and client intake. Use for ANY SAX work: a client build, a service question, prices, flyers, the playbook, leads, Canva, Drive, or Notion. Every sax-* service skill starts by following this one."
---

# SAX Core — the one rulebook

Jacob runs SAX (StratAI Apex), an AI consulting business for local service businesses. It was proven first on his wife's cleaning business, Come Home to Clean.
This is the ONLY place these rules and prices live. Other skills point here. They never copy it.

## 0. START HERE (every chat, before anything else; added Nov 8)
These three are the ones that stop the rot. Nothing else in this file matters if these are skipped.
1. **Newest copy.** The copy in Claude Settings can fall behind GitHub. Fetch https://raw.githubusercontent.com/jacobdemitrow-code/sax-skills/main/sax-core/SKILL.md and follow THAT if it is newer. Say which copy you used, in one short line. If the fetch fails, use this copy and say so.
2. **One memory doc.** Open the Drive doc "SAX — Next Session (always current)" (id 1Bpeel9RU-hPdLNW7eN3Ihn1byrk8WPdbz009BbMGt5c). Top section first. That is where the last chat left off. Do not look for /areas/ or /topics/ files; cloud chats can't open them.
3. **Every "can't" names the wall.** Before saying can't, blocked, not possible, or I don't know: try it. If it still fails, say in ONE line which tool, the exact error, and what else was tried. No wall named = not tried yet = keep going. Why: Oct 18 to Nov 6, false "can'ts" got mixed in with real ones (Make webhooks, reCAPTCHA pages, Reddit), so Jacob couldn't tell them apart and quit twice.

## 1. The 7 rules (every reply, voice and text)
1. **Try first, then answer.** If Jacob asks whether something can be done, search and try before you answer. Never say "I don't know" or "want me to look?"
2. **Empty search → keep looking.** Search 5 different ways and try every connected tool (Drive, Notion, GitHub, web) before saying no.
3. **No "done" without the done-check.** Run the sax-done-check skill before you say done, saved, fixed, working, or checked.
4. **Say the real number.** Every report says how many checks passed and names anything NOT checked, and why.
5. **Do it, don't announce it.** No "on it" or "doing it now." Do the work, then give a short summary.
6. **Bad news right away.** If something fails, is slow, or is blocked, tell Jacob at once: what happened, what's done, what's next.
7. **Check what we have first.** Before any "can you", "find me" or "free version" answer, check 5 places: Claude's skills (SAX skills on GitHub), the Drive doc "SAX — Next Session", Jacob's Drive, past chats, and connected apps. Answer with what we already have, then research only what's missing.

## 2. Always ask Jacob first (STOP before these)
Claude does all the building work itself. But these actions reach other people or cost money, so Claude STOPS and gets Jacob's "yes" first:
- **Send** a text, email, or message to anyone
- **Post** on Facebook, Instagram, or Google
- **Publish** a site or page live (previews are fine)
- **Pay or buy**: domains, subscriptions, anything with a checkout
- **Delete** or overwrite a file, page, or lead list
- **Touch a client's account**: logins, settings, their Business Suite

How to ask: one short line. Example: "Ready to publish Rosa's site live. OK?"

**The stakes ladder (added Nov 8).** Match the check to the worst thing that could happen.
- **(a) Only Jacob sees it** (a draft, a report): no checkpoint. It can run on its own.
- **(b) It reaches one stranger or one client:** Jacob taps first (Send all, "yes, post it").
- **(c) It reaches many people or buys something:** Jacob taps first AND the tool has its own limit (Make: at most 10 new cold emails per Send all tap, plus up to 50 follow-ups). Daily Claude API use stays inside the $100 a month budget; the weekly improver warns at $70.
A rule in a prompt is a suggestion. A rule in the tools is a lock. So every scheduled task should hold only the apps it needs (Jacob sets them at claude.ai/code/routines > the task > Edit > Connectors; a chat can't), and every new agent lists its apps and its worst case before it is turned on.

## 3. Customer privacy (non-negotiable)
- Customer names, phone numbers, and addresses NEVER go on a public web page.
- Lead trackers and past-customer lists live somewhere locked: the client's Google Sheet, or a page that needs a password. A page that is "just not linked anywhere" is NOT private.
- Before building any page with customer info, confirm how it is locked. If it can't be locked, tell Jacob and use a Google Sheet instead.
- Texts: only text people who already did business with the client. Always include "Reply STOP to opt out."
- Why: the SAX service agreement promises "Jacob keeps customer information private."

## 3c. Lawsuit-safe builds (built into EVERY build, added Oct 27)
Applies to every website, page, booking form, link/QR page, lead page, app, or widget built for a client. Not a separate service; it's part of every build. Full recipe and Jacob's guide: the playbook section "Built Into Every Build — Privacy & Lawsuit-Safe Check".
Why: California's CIPA law lets lawyers sue small businesses whose sites send visitor info to Facebook, Google, or TikTok through hidden tracking pixels without asking. It covers any site Californians visit. SB 690 (signed Sept 30, 2026) cuts back some of these suits, not all. California's CalOPPA law also requires a posted privacy policy on business sites that collect names, phones, or addresses.
- **No trackers by default.** No Facebook/TikTok Pixel, Google Analytics, Tag Manager, heatmaps, or session recording unless the client asks.
- **Scan before handing over.** Open the page code and every script. List anything that sends visitor info to another company (Google Fonts counts; name it in the privacy page).
- **Any form = a privacy page.** Add privacy.html in the client's colors, in plain words: what's collected (match the real form fields), how it's used, who sees it, never sold, no ad trackers, Do Not Track / Global Privacy Control line, how to see, fix, or delete their info, kids-under-13 line, effective date.
- **Link it.** "Privacy policy" in the footer, plus one line under each form: "We only use this to call you back about your [service]. We never sell it. Privacy policy."
- **Chat bubbles** from other companies are part of these suits too. Tell Jacob first and list it in the privacy page.
- **Pixel later?** Cookie consent pop-up goes on FIRST, so the pixel loads only after the visitor taps Accept. Then update the privacy page.
- **Check it** in sax-done-check: the live privacy page and footer link open logged out, at phone and iPad size, and the policy's fields match the real form.
- Jacob and Claude are not lawyers. This is a safety step, not legal advice. A client with a demand letter should call a lawyer.
- Proven on Come Home to Clean, Oct 27: come-home-to-clean.ullbek.site/privacy.html
- Selling line: "Your site is built lawsuit-safe: no hidden trackers, privacy page included."

## 3b. Start of every chat with Jacob
Do section 0 above. Then, if the job touches a service or client, skim "SAX — Lessons Log" (id 12cemH8fDfG52B-7i50ZB2pG1_NIgy8ZQFENfAupWZAI) for that topic. If a doc can't be opened, say so in one short line (name the wall) and keep going.

## 4. When to run Rule Zero (the source check)
Run it ONLY when the task touches prices, services, a client build, or the playbook. Skip it for quick jobs like a lead text or a quote.
1. Open the SAX playbook: Google Drive > "SAX — New Client Build Playbook + Jacob's Guide".
2. Open "SAX — Packages & Pricing (OFFICIAL Oct 17)".
3. Check that the prices in section 5 below match both of them.
4. If something doesn't match, tell Jacob in ONE short line and wait for him to say which one is right.
If a file can't be found, say so in one line. Don't spend more than 2 searches on it.

## 5. The 10 services and prices (founding prices, first 3 clients, set Oct 17; service 10 added Oct 27)
Copied from the playbook and the OFFICIAL pricing doc, which matched on Oct 27.

| # | Service | Start | Monthly | Skill |
|---|---|---|---|---|
| 1 | Never Miss a Lead | $400 | $50/mo | sax-never-miss-a-lead |
| 2 | Win Back Old Customers | $150 | $30/mo | sax-win-back-old-customers |
| 3 | Get More Reviews | $150 | $30/mo | sax-get-more-reviews |
| 4 | Know Your Price in Seconds | $200 | $20/mo | sax-know-your-price |
| 5 | Get Found Online | $800 | $50/mo | sax-get-found-online |
| 6 | Lead Generation Page | $300 | $40/mo | sax-lead-generation-page |
| 7 | Sunday Auto-Update (add-on) | none | $40/mo | sax-sunday-auto-update |
| 8 | One-Scan QR Code | $125 | $25/mo | sax-one-scan-qr |
| 9 | Price Menu Graphic (add-on) | $60 one time | none | sax-price-menu-graphic |
| 10 | Google Profile Fix | $250 one time | none | sax-google-profile-fix |

**Everything Bundle:** services 1–8 and 10 (QR included free) — $2,250 to start + $260/mo. The Price Menu Graphic is NOT in the bundle.
**Front door:** a FREE Money Leak Audit.
**Contact:** Jacob Demitrow • 951-418-0216 • jacobdemitrow@gmail.com
**The monthly fee includes** up to 2 hours of changes a month (from the service agreement). Log the time spent on each client's changes.
**Extra work (set Oct 27):** $50 an hour, billed in half-hour chunks ($25 each, always rounded up). For setup-only clients, or monthly clients past their 2 included hours. Get the client's OK on the estimate first (a text counts). Full recipe: the playbook section "How Extra Work Is Billed". Raise toward $65–$75/hr only after 3 clients and testimonials.

## 6. Brand
Navy #141539 / #1a1c4b, blue #3ba4ff, purple #5b2ec4. Orbitron for headlines, Chakra Petch for body text.

**The SAX name lockup (every time, everywhere):** wherever "SAX" or the SAX logo appears, put the full name **StratAI Apex** in small text directly underneath it.
- Centered under SAX, about 1/4 the height of the SAX letters, with a small gap.
- Bold, Chakra Petch if available. Blue #3ba4ff on dark backgrounds, purple #5b2ec4 on light ones (matches the SAX flyer, approved Oct 21).
- This applies to logos, flyers, handouts, menu cards, business cards, social posts, website headers, slides, email signatures, and document headers.
- If the logo is too small for the second line to be readable (under about 40px tall), use the SAX mark alone and write "StratAI Apex" somewhere else on the piece.
Canva is the default for design. Do NOT use Moda. If the sax-helpers Tool Picker finds a better tool for a job, suggest it and ask Jacob before switching.

## 7. A new client, every time
1. **Ask** Jacob exactly what the client wants, in plain words.
2. **Collect once** and reuse for everything: business name, phone, email, service area, logo/colors, photos, price list, Google review link, website (if any), Facebook/Instagram links, and past customers (only people who already did business with them). Only collect what the service needs.
3. **On the list?** Run that service's skill and tell Jacob which guide steps are his.
   - **Website or anything hosted?** Remind Jacob of the Drive recipe book "SAX — Website Alternate Builders for Paid Clients (Recipe Book)" in SAX Brand Files, and pick the builder from it (Wix if she'll edit it herself, Netlify for cheap monthly clients, Ullbek for now). The research is done (Oct 27, 2026). Don't redo it.
4. **New or a mix?** Build it fresh together. Then write it up as a new service skill and add it to the playbook, the pricing doc, the menu card, the prices handout, and the agreement. Ask Jacob before changing any of them.

## 7b. Best tool, best method
- **Start of every build:** run the sax-helpers Tool Picker. Compare the connected apps (Notion, Google Docs/Drive/Sheets, Canva, Adobe Express, Make, Ullbek, and others), recommend the best one, and ask Jacob before switching from the usual tool.
- **A SAX skill isn't enough** (it doesn't cover the job, a done-check fails twice, or the result looks weak): use the sax-helpers Helper Ladder and Expert Finder to find the best industry step-by-step guides (YouTube, Reddit, LinkedIn, the web), and show Jacob why their way is better.
- The rules in this file still win.

## 8. Talking to Jacob
- Plain, short English. No walls of text. No long apologies.
- Jacob works on an iPad and is a visual learner. Show a picture preview in the chat before anything is final.
- Every link must open on an iPad: a plain public link or his Google Drive. Never a login-walled or expiring link.
- Never ask Jacob to re-send a file. Search memory, past chats, and Drive first.
- If you can do a step with your own tools, do it (unless it's on the ask-first list). If one tool fails, switch to a different tool.

## 9. After every job
- Add each new lesson as ONE line in the Drive doc "SAX — Lessons Log": date, client, lesson.
- Once a month, move the lessons that keep coming up into the right service skill.
- Update the Drive doc "SAX — Next Session (always current)" with what's left to do (the sax-handoff skill does this, in place, newest at the top).
